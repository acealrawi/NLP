For mac users: 

If you click the file pcpatr, a terminal window with PC-PATR (version 1.4.4) should open. 

If that doesn't work, try the following steps:

* open a terminal window yourself
* in the terminal window, navigate to the folder with "pcpatr" (for example "cd Downloads")
* type the commando "pcpatr" in the terminal window

